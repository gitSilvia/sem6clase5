<?php
define('MAQUINA', 'localhost');
define('USUARIO', 'root');
define('CLAVE', '');
define('BASE', 'basepoo24');
define('CODIFICACION', 'utf8');

/*Datos para reportes y factura*/
define('NOMBRE_EMPRESA', 'EMPRESA DE PRUEBA S.A.');
define('DIRECCION_EMPRESA', 'RUTA PY02 Km 180, Caaguazú, Paraguay');
define('TELEFONO_EMPRESA', '+595 522 48888');
define('EMAIL_EMPRESA', 'epruebasa@gmail.com');
define('IMPUESTO', '10');
?>
