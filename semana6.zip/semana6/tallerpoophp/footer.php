<!-- SCRIPTS -->
<script src="/semana6/tallerpoophp/js/jquery.min.js"></script>
<script src="/semana6/tallerpoophp/js/popper.min.js"></script>
<script src="/semana6/tallerpoophp/js/bootstrap.min.js"></script>
<script src="/semana6/tallerpoophp/js/sweetalert2.all.min.js"></script>
<script src="/semana6/tallerpoophp/js/select2.min.js"></script>
<script src="/semana6/tallerpoophp/js/all.min.js"></script>
<script src="/semana6/tallerpoophp/js/moment.min.js"></script>
<script src="/semana6/tallerpoophp/js/windowcenter.js"></script>
<script src="/semana6/tallerpoophp/js/index.js"></script>
