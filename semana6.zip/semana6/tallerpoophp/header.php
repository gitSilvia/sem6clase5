<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- BOOTSTRAP 4 -->
<link rel="stylesheet" href="/semana6/tallerpoophp/css/bootstrap.min.css">
<link rel="stylesheet" href="/semana6/tallerpoophp/css/all.min.css">
<link rel="stylesheet" href="/semana6/tallerpoophp/css/sweetalert2.min.css">
<link rel="stylesheet" href="/semana6/tallerpoophp/css/select2.min.css">
<link rel="stylesheet" href="/semana6/tallerpoophp/css/index.css">

<!-- <link rel="stylesheet" href="/semana6/tallerpoophp/css/mystyle.css"> -->
