<?php
  header("location: ../");
?>